import os
import json
import pickle
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity, euclidean_distances
from tqdm import tqdm, trange
import torch
import numpy as np
import time
import random
from itertools import combinations
from sklearn.metrics import pairwise_distances
from sklearn.metrics.pairwise import cosine_similarity, euclidean_distances
from sklearn.decomposition import PCA, KernelPCA
from sklearn.svm import SVC
from sklearn.metrics import f1_score, recall_score
from sklearn.model_selection import train_test_split as svm_train_test_split
from sklearn.utils import resample
from sklearn import svm
from sklearn.metrics import classification_report
from sklearn.model_selection import StratifiedKFold
from sklearn.datasets import make_classification
from imblearn.over_sampling import SMOTE
from statistics import mean, stdev
import torch.nn.functional as F
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import argparse
import warnings
from sklearn.exceptions import ConvergenceWarning
from sklearn.covariance import LedoitWolf, MinCovDet
from sklearn.preprocessing import scale, normalize, StandardScaler
from sklearn.datasets import fetch_20newsgroups
from sklearn.manifold import MDS
from numpy.linalg import inv, norm, det
from scipy.linalg import logm
from scipy.spatial.distance import pdist, squareform, cosine
from scipy.stats import ks_2samp, mannwhitneyu
from functools import reduce
import sys
import skbio
from skbio import DistanceMatrix
import scipy.io
import pickle
import torch
from scipy.linalg import logm
from numpy.linalg import inv, norm, det
from sentence_transformers import SentenceTransformer
from tqdm import trange
from numpy import inf
import math
import numpy as np
from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.covariance import LedoitWolf, MinCovDet
from sklearn.metrics import mean_squared_error
from logME import LogME
from sklearn.metrics.pairwise import pairwise_kernels

from pdb import set_trace as keyboard

def check_numbers(config):
    assert config.n_samples_per_group <= config.n_neg
    assert config.n_samples_per_group <= config.n_pos
    assert config.n_combo <= math.factorial(config.n_pos) // (math.factorial(config.n_samples_per_group) * math.factorial(config.n_pos - config.n_samples_per_group))
    assert config.n_combo * config.n_neg // config.n_pos <= math.factorial(config.n_neg) // (math.factorial(config.n_samples_per_group) * math.factorial(config.n_neg - config.n_samples_per_group))

def log_dist(p1, p2): #suppress warning
    original_stdout = sys.stdout
    try:
        with open(os.devnull, 'w') as devnull:
            sys.stdout = devnull

            A1 = logm(p1)
            A2 = logm(p2)
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        sys.stdout = original_stdout 
    return norm(A1-A2)

def create_text_model(model_name, device='cpu'):
    model = SentenceTransformer(model_name).to(device).eval()
    return model


def create_conditional_embedding(model, query, samples, device):
    max_length = 0
    embeddings = []
    masks = []
    query = torch.Tensor(query).to(device)

    for sample in samples:
        sample_embeddings = model.encode(sample, output_value='token_embeddings')
        embeddings.append(sample_embeddings)
        max_length = max(max_length, sample_embeddings.size(0))
    
    for i in range(len(embeddings)):
        mask = torch.cat((torch.zeros(embeddings[i].size(0)), torch.ones(max_length - embeddings[i].size(0))), dim=0).to(device).bool()
        masks.append(mask.view(1, -1))
        embeddings[i] = torch.nn.functional.pad(embeddings[i], (0, 0, 0, max_length - embeddings[i].size(0)), mode='constant', value=0).unsqueeze(0)
        
    masks = torch.cat(masks, dim=0)
    embeddings = torch.cat(embeddings, dim=0)
    attention = (embeddings @ query.t()).squeeze(-1)
    attention = attention.masked_fill(masks, -inf)
    attention = (torch.nn.Softmax(dim=1)(attention)).unsqueeze(-1)
    embeddings = (embeddings * attention).sum(dim=1)

    return embeddings.cpu().numpy()

def create_unconditional_embedding(model, samples, device):
    embeddings = []
    for sample in samples:
        sample_embeddings = model.encode(sample).reshape(-1)
        embeddings.append(sample_embeddings)
    
    return embeddings

def create_embeddings(df, model, device):
    embeddings = []

    for i in trange(df.shape[0]):
        query = df.iloc[i]['query']
        query_embedding = model.encode([query])

        positive_samples = df.iloc[i]['pos_samples']
        # positive_sample_embeddings = create_conditional_embedding(model, query_embedding, positive_samples, device)
        positive_sample_embeddings = create_unconditional_embedding(model, positive_samples, device)

        negative_samples = df.iloc[i]['neg_samples']
        # negative_sample_embeddings = create_conditional_embedding(model, query_embedding, negative_samples, device)
        negative_sample_embeddings = create_unconditional_embedding(model, negative_samples, device)

        positive_samples_score = np.matmul(normalize(query_embedding), normalize(np.array(positive_sample_embeddings)).T)
        negative_samples_score = np.matmul(normalize(query_embedding), normalize(np.array(negative_sample_embeddings)).T)
        positive_sample_prob = np.exp(positive_samples_score) / (np.exp(positive_samples_score) + np.exp(negative_samples_score).sum())
        mean_positive_log_prob = np.log(positive_sample_prob).mean()

        embeddings.append({'query_embedding': query_embedding, 'pos_embeddings': positive_sample_embeddings, 'neg_embeddings': negative_sample_embeddings, 'mean_positive_log_prob': mean_positive_log_prob})
        
    return embeddings

def load_embeddings(filename):
    data = []
    with open(filename, 'r') as f:
        for line in f: 
            data.append(json.loads(line))
            
    id_to_embed = {}
    for i in range(len(data)):
        id_to_embed[str(data[i]['id'])] = data[i]['embedding']
    return id_to_embed

def use_pre_computed_embeddings(df, dataset, embeddings_dir):
    embedding_files = [
        f"{dataset}.embeddings.out",
        f"{dataset}.embeddings.queries.out",
        f"{dataset}.embeddings.aug.out",
    ]
    
    id_to_embed = {}
    for embed_file in embedding_files:
        embed_file_path = os.path.join(embeddings_dir, embed_file)

        if os.path.exists(embed_file_path):
            cur_id_to_embed = load_embeddings(embed_file_path)
            id_to_embed.update(cur_id_to_embed)
            
    if 'query_id' not in df.columns:
        df['query_id'] = df.index

    embeddings = []

    for i in trange(df.shape[0]):
        query_id = df.iloc[i]['query_id']
        query_embedding = np.array(id_to_embed[str(query_id)]).reshape(1, -1)

        pos_ids = df.iloc[i]['pos_id']
        pos_ids = [str(pos_id) for pos_id in pos_ids]
        positive_sample_embeddings = [np.array(id_to_embed[pos_id]).reshape(1, -1) for pos_id in pos_ids if pos_id in id_to_embed]
        positive_sample_embeddings = np.concatenate(positive_sample_embeddings, axis=0)

        neg_ids = df.iloc[i]['neg_id']
        neg_ids = [str(neg_id) for neg_id in neg_ids]
        negative_sample_embeddings = [np.array(id_to_embed[neg_id]).reshape(1, -1) for neg_id in neg_ids if neg_id in id_to_embed]
        negative_sample_embeddings = np.concatenate(negative_sample_embeddings, axis=0)

        positive_samples_score = np.matmul(normalize(query_embedding), normalize(np.array(positive_sample_embeddings)).T)
        negative_samples_score = np.matmul(normalize(query_embedding), normalize(np.array(negative_sample_embeddings)).T)
        positive_sample_prob = np.exp(positive_samples_score) / (np.exp(positive_samples_score) + np.exp(negative_samples_score).sum())
        mean_positive_log_prob = np.log(positive_sample_prob).mean()

        embeddings.append({'query_embedding': query_embedding, 'pos_embeddings': positive_sample_embeddings, 'neg_embeddings': negative_sample_embeddings, 'mean_positive_log_prob': mean_positive_log_prob})
            
    return embeddings


def weighted_difference(weight, mean_diff, cov_diff):
    return weight * mean_diff + (1 - weight) * cov_diff


def find_optimal_weight(embeddings1, embeddings2):
    # Prepare the data for cross-validation
    data = np.concatenate([embeddings1, embeddings2])
    labels = np.concatenate([np.zeros(embeddings1.shape[0]), np.ones(embeddings2.shape[0])])
    
    # Set up the cross-validation using KFold
    #kf = KFold(n_splits=5, shuffle=True, random_state=42)
    kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    # Initialize variables to store the optimal weight and the minimum error
    optimal_weight = 0
    min_error = float("inf")

    # Loop through the possible weights (you can use a finer grid if needed)
    for weight in np.arange(0, 1.1, 0.1):
        cv_errors = []

        # Perform cross-validation
        for train_idx, val_idx in kf.split(data, labels):
            
            train_data = data[train_idx]
            train_labels = labels[train_idx]
            val_data = data[val_idx]
            val_labels = labels[val_idx]

            # print(train_data[train_labels == 0].shape)
            # print(train_data[train_labels == 1].shape)
            
            try:
                # Calculate the mean and covariance differences
                mean_diff = np.linalg.norm(train_data[train_labels == 0].mean(axis=0) - train_data[train_labels == 1].mean(axis=0))
                #mean_diff = cosine(train_data[train_labels == 0].mean(axis=0), train_data[train_labels == 1].mean(axis=0))
                cov_diff = log_dist(LedoitWolf().fit(train_data[train_labels == 0]).covariance_, LedoitWolf().fit(train_data[train_labels == 1]).covariance_)

                    # Calculate the weighted differences for the validation set
                val_mean_diff = np.linalg.norm(val_data[val_labels == 0].mean(axis=0) - val_data[val_labels == 1].mean(axis=0))
                #val_mean_diff = cosine(val_data[val_labels == 0].mean(axis=0), val_data[val_labels == 1].mean(axis=0))
                val_cov_diff = log_dist(LedoitWolf().fit(val_data[val_labels == 0]).covariance_, LedoitWolf().fit(val_data[val_labels == 1]).covariance_)
                val_weighted_diff = weighted_difference(weight, val_mean_diff, val_cov_diff)
            except:
                continue
            
            # Calculate the true weighted difference for the training set
            true_weighted_diff = weighted_difference(weight, mean_diff, cov_diff)
            
            # Calculate the mean squared error
            mse = mean_squared_error([true_weighted_diff], [val_weighted_diff])
            cv_errors.append(mse)

        # Calculate the average error across all folds
        avg_error = np.mean(cv_errors)
        
        # Update the optimal weight and minimum error if necessary
        if avg_error < min_error:
            min_error = avg_error
            optimal_weight = weight
    
    return optimal_weight

def BC_dist(mu1, cov1, mu2, cov2):
    mean_cov = 0.5 * (cov1 + cov2)
    d = ((mu1 - mu2).T @ np.linalg.inv(mean_cov) @ (mu1 - mu2) / 8.).reshape(-1)[0]\
            + np.log(np.linalg.det(mean_cov)/(np.linalg.det(cov1) * np.linalg.det(cov2))**0.5) / 2.
    return -np.exp(-d)

def calculate_stats_for_transformed_embeddings(
    transformed_positive_embeddings, 
    transformed_negative_embeddings, 
    n_combo, 
    n_pos,
    n_samples,
    n_neg,
    original_vector_mean_dis=None,
    original_vector_cov_dis=None
    ):

    positive_cov_reduced_vector = LedoitWolf().fit(transformed_positive_embeddings).covariance_
    negative_cov_reduced_vector = LedoitWolf().fit(transformed_negative_embeddings).covariance_

    positive_mean_reduced_vector = np.mean(transformed_positive_embeddings, axis=0)
    negative_mean_reduced_vector = np.mean(transformed_negative_embeddings, axis=0)
    
    BC = BC_dist(positive_mean_reduced_vector, positive_cov_reduced_vector, negative_mean_reduced_vector, negative_cov_reduced_vector)

    return BC
    
def MMD(X, Y, kernel='rbf', **kwargs):
    n = X.shape[0]
    m = Y.shape[0]

    # Compute pairwise kernel values
    K_YY = pairwise_kernels(Y, Y, metric=kernel, **kwargs)
    np.fill_diagonal(K_YY, 0)
    
    K_XX = pairwise_kernels(X, X, metric=kernel, **kwargs)
    np.fill_diagonal(K_XX, 0)
    K_XY = pairwise_kernels(X, Y, metric=kernel, **kwargs)
    #return (np.sum(K_XX) / (n * (n - 1)) + np.sum(K_YY) / (m * (m - 1)) - 2 * K_XY.mean()) 
    #return (np.sum(K_XX) / (n * (n - 1)) + np.sum(K_YY) / (m * (m - 1)) - 2 * np.sum(K_XY)/(m*n)) 
    kxx = np.sum(K_XX) / (n * (n - 1))
    kyy = np.sum(K_YY) / (m * (m - 1))
    kxy = np.sum(K_XY)/(m*n)
    return kxx + kyy - 2*kxy, kxx, kyy, kxy


def compute_MMD(query_embedding, other_embeddings, kernel='rbf', **kwargs):
    n = 1  # since query_embedding is just a single point
    m = other_embeddings.shape[0]

    # Compute pairwise kernel values
    K_QQ = pairwise_kernels(query_embedding, query_embedding, metric=kernel, **kwargs)
    K_OO = pairwise_kernels(other_embeddings, other_embeddings, metric=kernel, **kwargs)
    np.fill_diagonal(K_OO, 0)
    K_QO = pairwise_kernels(query_embedding, other_embeddings, metric=kernel, **kwargs)

    return K_QQ.mean() + (np.sum(K_OO) / (m * (m - 1))) - 2 * K_QO.mean()
    

def twonn_dimension(X):
    """
    Estimate intrinsic dimensionality using the Two Nearest Neighbors (TWONN) method.
    
    Parameters:
    - X: numpy array of shape (n_samples, n_features) - the data embeddings
    
    Returns:
    - Estimated intrinsic dimension
    """
    
    # Compute pairwise distances
    distances = euclidean_distances(X)
    
    # Set diagonal to high value to exclude self-distance
    np.fill_diagonal(distances, np.inf)
    
    # Sort each row and pick the first and second smallest values (smallest being the nearest neighbor)
    r1 = np.sort(distances)[:, 0]
    r2 = np.sort(distances)[:, 1]
    
    # Compute average ratio
    rho_avg = np.mean(r1 / r2)
    
    # Estimate intrinsic dimension
    D = 2 * np.log(2) / -np.log(rho_avg)
    
    return D


def mds_dimension(embeddings):
    batch_size = embeddings.shape[0] 

    D = pairwise_distances(embeddings)   
    D = D / np.amax(D)
    
    l_sorted = cmdscale(D) 
    #l_sorted = eigen_mds(D)          
    
    # Calculate k based on number of large eigenvalues
    k = next(x[0] for x in enumerate(l_sorted) if x[1] < 0.01 * l_sorted[0])  
    
    return k



def cmdscale(D):
    """                                                                                       
    Classical multidimensional scaling (MDS)                                                  
                                                                                               
    Parameters                                                                                
    ----------                                                                                
    D : (n, n) array                                                                          
        Symmetric distance matrix.                                                            
                                                                                               
    Returns                                                                                   
    -------                                                                                   
    Y : (n, p) array                                                                          
        Configuration matrix. Each column represents a dimension. Only the                    
        p dimensions corresponding to positive eigenvalues of B are returned.                 
        Note that each dimension is only determined up to an overall sign,                    
        corresponding to a reflection.                                                        
                                                                                               
    e : (n,) array                                                                            
        Eigenvalues of B.                                                                     
                                                                                               
    """
    
    # Number of points                                                                        
    n = len(D)
 
    # Centering matrix                                                                        
    H = np.eye(n) - np.ones((n, n))/n
 
    # YY^T                                                                                    
    B = -H.dot(D**2).dot(H)/2
 
    # Diagonalize                                                                             
    evals, evecs = np.linalg.eigh(B)
 
    # Sort by eigenvalue in descending order                                                  
    idx   = np.argsort(evals)[::-1]
    evals = evals[idx]
    evecs = evecs[:,idx]
 
    return np.sort(evals)[::-1]


def eigen_mds(pd):   
    mds = MDS(n_components=len(pd), dissimilarity='precomputed')
    pts = mds.fit_transform(pd)

    _,l_sorted,_ = np.linalg.svd(pts)
    
    return l_sorted


def permutation_test_mmd(x, y, kernel, degree=None, num_permutations=1000):
    
    # Assuming you have a MMD function that works with numpy arrays
    if kernel == 'poly':
        mmd_observed,_,_,_ = MMD(x, y, kernel='poly', degree=degree)
    else:
        mmd_observed,_,_,_ = MMD(x, y, kernel)
    
    combined = np.concatenate([x, y], axis=0)
    mmd_permuted_values = []
    
    for _ in range(num_permutations):
        perm_indices = np.random.permutation(len(combined))
        permuted = combined[perm_indices]
        x_perm = permuted[:len(x)]
        y_perm = permuted[len(x):]
        
        if kernel == 'poly':
            mmd_permuted,_,_,_ = MMD(x_perm, y_perm, kernel='poly', degree=degree)
        else:
            mmd_permuted,_,_,_ = MMD(x_perm, y_perm, kernel)
            
        mmd_permuted_values.append(mmd_permuted)
    
    # Calculate p-value
    mmd_permuted_values = np.array(mmd_permuted_values)
    p_value = np.mean(mmd_observed < mmd_permuted_values)
    
    return p_value


import numpy as np
from sklearn.decomposition import PCA
from scipy.spatial import distance

def compute_curvature(embeddings, p, k=5):
    """
    Compute curvature of data based on PCA and circle fitting.
    
    Parameters:
    - embeddings: The set of embeddings.
    - k: Number of nearest neighbors to consider for circle fitting.
    
    Returns:
    - Average curvature of the data.
    """
    
    # Step 1: Project embeddings to first two principal components
    pca = PCA(n_components=p)
    projected_data = pca.fit_transform(embeddings)
    
    # Step 2: For every point, compute the curvature
    curvatures = []
    for point in projected_data:
        # Compute distances to other points
        distances = np.apply_along_axis(lambda x: distance.euclidean(x, point), 1, projected_data)
        # Get k nearest neighbors
        neighbors = projected_data[np.argsort(distances)[:k]]
        
        # Circle fitting
        # Using the formula: curvature = 1 / R, where R is the radius of the circle
        # We use a simple mean for R estimation from the distances
        R = np.mean(distances[np.argsort(distances)[:k]])
        curvature = 1 / R if R != 0 else 0  # Avoid division by zero
        
        curvatures.append(curvature)
        
    # Step 3: Return average curvature
    return np.mean(curvatures)


import ot 

def compute_wasserstein(X, Y):
    # Compute pairwise distance matrices for X and Y
    Mxx = ot.dist(X, X)
    Myy = ot.dist(Y, Y)
    Mxy = ot.dist(X, Y)
    
    # Compute marginals
    px = np.ones(X.shape[0]) / X.shape[0]
    py = np.ones(Y.shape[0]) / Y.shape[0]

    # Compute Wasserstein distance
    wasserstein_distance = ot.emd2(px, py, Mxy)
    
    return wasserstein_distance


def calculate_scores( 
    embeddings_lists, 
    n_combo,
    n_pos,
    n_samples,
    n_neg,
    n_components):
    
    BC_pca_list = []
    mmd_scores = {i+1: [] for i in range(10)}
    cnt_p_value = 0
    f1_list = []
    kernel_type = 'rbf'

    for i in trange(len(embeddings_lists)):
        query_embedding = embeddings_lists[i]['query_embedding']
        positive_embeddings = embeddings_lists[i]['pos_embeddings']
        negative_embeddings = embeddings_lists[i]['neg_embeddings']

        embeddings = np.vstack((query_embedding, positive_embeddings, negative_embeddings))

        sc = StandardScaler()
        standardized_embeddings = sc.fit_transform(embeddings)

        ## Calculating MMD
        pca = PCA()
        pca.fit(standardized_embeddings)
        explained_variance_ratio = pca.explained_variance_ratio_.cumsum()
        n_components = (explained_variance_ratio < 0.9).sum() + 1

        positive_pca = PCA(n_components=n_components)
        transformed_embeddings = positive_pca.fit_transform(standardized_embeddings)
        pca_transformed_query_embedding = transformed_embeddings[0, :].reshape(1,-1)
        pca_transformed_positive_embeddings = transformed_embeddings[1:len(positive_embeddings)+1, :]
        pca_transformed_negative_embeddings = transformed_embeddings[len(positive_embeddings)+1:, :]

        # SVM
        # X = np.concatenate([pca_transformed_positive_embeddings, pca_transformed_negative_embeddings], axis=0)
        # y = np.array([1] * len(pca_transformed_positive_embeddings) + [0] * len(pca_transformed_negative_embeddings))  # 1 for positive, 0 for negative
        # # X_train, X_test, y_train, y_test = svm_train_test_split(X, y, test_size=0.2)
        # # # smote = SMOTE(k_neighbors=min(len(y_train[y_train == 1]) - 1, 5))
        # # # X_train, y_train= smote.fit_resample(X_train, y_train)
        # # svm_clf = SVC(kernel='rbf')
        # # svm_clf.fit(X_train, y_train)
        # # y_pred = svm_clf.predict(X_test)
        # # f1 = f1_score(y_test, y_pred)
        # # #recall = recall_score(y_test, y_pred)
        # # f1_list.append(f1)

        # skf = StratifiedKFold(n_splits=5)
        # for train_index, test_index in skf.split(X, y):
        #     X_train, X_test = X[train_index], X[test_index]
        #     y_train, y_test = y[train_index], y[test_index]
        #     # Initialize and train the SVM classifier
        #     svm_clf = svm.SVC(kernel='poly')
        #     svm_clf.fit(X_train, y_train)
        #     # Make predictions on the test set
        #     y_pred = svm_clf.predict(X_test)
        #     f1 = f1_score(y_test, y_pred)
        #     #recall = recall_score(y_test, y_pred)
        #     f1_list.append(f1)

        # p_val = permutation_test_mmd(pca_transformed_positive_embeddings, pca_transformed_negative_embeddings, kernel_type, degree=i+1, num_permutations=1000)
        # if p_val < 0.05:
        #     cnt_p_value += 1 

        # for i in range(1):
        #     mmd_value, kxx, kyy, kxy = MMD(pca_transformed_positive_embeddings, pca_transformed_negative_embeddings, kernel='linear',degree=i+1)
        #     mmd_scores[i+1].append(mmd_value)

        for i in range(1):
            mmd_value, kxx, kyy, kxy = MMD(pca_transformed_positive_embeddings, pca_transformed_negative_embeddings, kernel=kernel_type)
            #mmd_value = compute_wasserstein(pca_transformed_positive_embeddings, pca_transformed_negative_embeddings) 
            mmd_scores[i+1].append(mmd_value)
            #mmd_scores[i+1].append(np.exp(kxx-kxy))


        ## Calculating GBC
        positive_pca = PCA(n_components=5)
        BC_transformed_embeddings = positive_pca.fit_transform(standardized_embeddings)
        pca_transformed_positive_embeddings = BC_transformed_embeddings[:len(positive_embeddings), :]
        pca_transformed_negative_embeddings = BC_transformed_embeddings[len(positive_embeddings):, :]

        BC_pca = calculate_stats_for_transformed_embeddings(
            pca_transformed_positive_embeddings, 
            pca_transformed_negative_embeddings, 
            n_combo, 
            n_pos,
            n_samples,
            n_neg,)
            
        BC_pca_list.append(BC_pca)

    #estimated_dimension = twonn_dimension(embeddings)
    # estimated_dimension = mds_dimension(embeddings)
    # estimated_dimension = compute_curvature(embeddings, p=n_components, k=5)
    # print('curvature:', estimated_dimension)

    # #print('Number of significant p-value:', cnt_p_value)
    # #estimated_dimension = mds_dimension(embeddings)
    # estimated_dimension = twonn_dimension(embeddings)
    # print()
    # print('dimension:', estimated_dimension)

    # print('f1:', np.mean(f1_list), np.std(f1_list))
    # print(kernel_type, 'count of significant p-value:', cnt_p_value)

    print(np.sum(mmd_scores[1]),4)
        
    results = {
        'MMD 1': round(np.mean(mmd_scores[1]),4), 
        'MMD 2': round(np.log(np.sum(mmd_scores[2])+1e-6),4),
        'MMD 3': round(np.log(np.sum(mmd_scores[3])+1e-6),4),
        'MMD 4': round(np.log(np.sum(mmd_scores[4])+1e-6),4),
        'MMD 5': round(np.log(np.sum(mmd_scores[5])+1e-6),4),
        'MMD 6': round(np.log(np.sum(mmd_scores[6])+1e-6),4),
        'MMD 7': round(np.log(np.sum(mmd_scores[7])+1e-6),4),
        'MMD 8': round(np.log(np.sum(mmd_scores[8])+1e-6),4),
        'MMD 9': round(np.log(np.sum(mmd_scores[9])+1e-6),4),
        'MMD 10': round(np.log(np.sum(mmd_scores[10])+1e-6),4),
        'BC distance PCA reduction': mean(BC_pca_list),
            }
    
    return results
        
        
